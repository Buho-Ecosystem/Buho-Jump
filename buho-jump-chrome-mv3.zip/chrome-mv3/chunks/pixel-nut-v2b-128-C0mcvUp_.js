const o="/logo/logo.svg",s="/NUTbits/pixel-nut-v2b-128.png";export{o as _,s as a};
